# MySqlPractice — задания с test_bd

Проект выполнен под .NET 5 WinForms и использует базу `test_bd` из файла `database/test_bd.sql`.

## Запуск
1. Установить Visual Studio 2019/2022 с рабочей нагрузкой «Разработка классических приложений .NET» и поддержкой .NET 5.
2. Запустить MySQL/MariaDB на `127.0.0.1:3306`.
3. Импортировать `database/test_bd.sql` в MySQL. В SQL-файле создаётся база `test_bd` и её таблицы.
4. Открыть файл `MySqlPractice.sln` в корне архива.
5. В Visual Studio выбрать конфигурацию `Debug` и запустить проект (`F5`).

Строка подключения:
`Server=127.0.0.1;Port=3306;Database=test_bd;Uid=root;Pwd=;CharSet=utf8mb4;`

Если у root установлен пароль, его нужно указать в `Form1.cs` вместо пустого `Pwd=`.

## Что выполнено
- SELECT и вывод `service_categories` в DataGridView.
- INSERT INTO через два TextBox и параметризованный запрос.
- Удаление выбранной строки через `SelectedRows[0].Cells["id"]`.
- Обработка ошибок через try/catch.
- Автоматическое обновление каждые 5 секунд.
- Отмена фонового обновления через CancellationToken при закрытии формы.

using System;
using System.Data;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace MySqlPractice
{
    public partial class Form1 : Form
    {
        // Подключение именно к БД test_bd из предоставленного SQL-файла.
        private string connectionString = "Server=127.0.0.1;Port=3306;Database=test_bd;Uid=root;Pwd=;CharSet=utf8mb4;";

        private CancellationTokenSource cancellationTokenSource;

        public Form1()
        {
            InitializeComponent();
        }

        private async void Form1_Load(object sender, EventArgs e)
        {
            await LoadData();

            cancellationTokenSource = new CancellationTokenSource();
            _ = UpdateData(cancellationTokenSource.Token);
        }

        // Задание 2: SELECT из БД и вывод в DataGridView.
        private async Task LoadData()
        {
            if (dataGridView1.InvokeRequired)
            {
                dataGridView1.Invoke(new Action(async () => await LoadData()));
                return;
            }

            try
            {
                using (MySqlConnection connection = new MySqlConnection(connectionString))
                {
                    await connection.OpenAsync();

                    string query = "SELECT id, name, description FROM service_categories ORDER BY id";

                    using (MySqlCommand command = new MySqlCommand(query, connection))
                    using (MySqlDataReader reader = (MySqlDataReader)await command.ExecuteReaderAsync())
                    {
                        DataTable dataTable = new DataTable();
                        dataTable.Load(reader);
                        dataGridView1.DataSource = dataTable;
                    }
                }

                dataGridView1.Columns["id"].HeaderText = "ID";
                dataGridView1.Columns["name"].HeaderText = "Название";
                dataGridView1.Columns["description"].HeaderText = "Описание";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Задание 2_1: INSERT INTO.
        private void InsertData(string column1Value, string column2Value)
        {
            try
            {
                using (MySqlConnection connection = new MySqlConnection(connectionString))
                {
                    connection.Open();

                    string query = "INSERT INTO service_categories (name, description) VALUES (@value1, @value2)";

                    using (MySqlCommand command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@value1", column1Value);
                        command.Parameters.AddWithValue("@value2", column2Value);

                        int rowsAffected = command.ExecuteNonQuery();
                        MessageBox.Show("Успешно добавлено строк: " + rowsAffected, "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private async void buttonInsert_Click(object sender, EventArgs e)
        {
            string value1 = textBoxName.Text.Trim();
            string value2 = textBoxDescription.Text.Trim();

            if (string.IsNullOrWhiteSpace(value1) || string.IsNullOrWhiteSpace(value2))
            {
                MessageBox.Show("Пожалуйста, заполните все поля.", "Предупреждение", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            InsertData(value1, value2);
            await LoadData();

            textBoxName.Clear();
            textBoxDescription.Clear();
        }

        // Задание 2_1: удаление выбранной строки из DataGridView.
        private void buttonDelete_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Сначала выберите строку.", "Предупреждение", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int id = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["id"].Value);

            try
            {
                using (MySqlConnection connection = new MySqlConnection(connectionString))
                {
                    connection.Open();

                    string query = "DELETE FROM service_categories WHERE id = @id";

                    using (MySqlCommand command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@id", id);
                        command.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Запись удалена.", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                _ = LoadData();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private async void buttonRefresh_Click(object sender, EventArgs e)
        {
            await LoadData();
        }

        // Задание 3: автоматическое обновление каждые 5 секунд.
        private async Task UpdateData(CancellationToken token)
        {
            while (!token.IsCancellationRequested)
            {
                try
                {
                    await Task.Delay(5000, token);
                    await LoadData();
                }
                catch (TaskCanceledException)
                {
                    break;
                }
                catch (Exception ex)
                {
                    if (!token.IsCancellationRequested)
                    {
                        if (IsHandleCreated)
                        {
                            BeginInvoke(new Action(() =>
                                MessageBox.Show("Ошибка обновления: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error)));
                        }
                    }
                }
            }
        }

        // Метод создан для события FormClosing, как указано в задании.
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (cancellationTokenSource != null)
            {
                cancellationTokenSource.Cancel();
            }
        }
    }
}
